import json
import logging
import pandas as pd
from sklearn.externals import joblib
import time

class Multi_Linear:
    def __init__(self):
        print("Locomotive Linear Regression")

    def driver(self, timeseries):
        loaded_model = "GranCanaria_SingleVariate.sav"
        model = joblib.load(loaded_model)
        test= json.loads(timeseries)
        #test = pd.DataFrame(data_json["test"])

        coef_lst = model.coef_
        feature_columns = ['wind_speed_a']
        result = test[feature_columns[i]][0] * coef_lst[0]

        return json.dumps({"Prediction" : result})

loaded_model = "finalized_model.sav"
model = joblib.load(loaded_model)
coef_lst = model.coef_
print(coef_lst)
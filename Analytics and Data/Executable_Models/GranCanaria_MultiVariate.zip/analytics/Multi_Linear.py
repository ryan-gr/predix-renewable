import json
import logging
import pandas as pd
from sklearn.externals import joblib
import time

class Multi_Linear:
    def __init__(self):
        print("Locomotive Linear Regression")

    def driver(self, timeseries):
        loaded_model = "gran_canaria.sav"
        model = joblib.load(loaded_model)
        test= json.loads(timeseries)
        #test = pd.DataFrame(data_json["test"])

        coef_lst = model.coef_
        feature_columns = ['wind_speed_a', "temperature_a", "time", "rate_of_change_a", "rate_of_change_b", "rate_of_change_c", "moving_ave_a", "moving_ave_b"]
        result = 0
        for i in range(8):
            if i == 2:
                ep_time = test[feature_columns[i]][0]
                result +=  time.gmtime(ep_time / 1000)[3] * coef_lst[i]
            else:
                result += test[feature_columns[i]][0] * coef_lst[i]

        return json.dumps({"Prediction" : result})